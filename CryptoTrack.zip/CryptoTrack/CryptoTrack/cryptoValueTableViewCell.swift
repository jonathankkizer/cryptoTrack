//
//  cryptoValueTableViewCell.swift
//  CryptoTrack
//
//  Created by Jonathan Kizer on 11/28/17.
//  Copyright © 2017 Jonathan Kizer. All rights reserved.
//

import UIKit

class cryptoValueTableViewCell: UITableViewCell {

    @IBOutlet weak var cryptoValueLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
